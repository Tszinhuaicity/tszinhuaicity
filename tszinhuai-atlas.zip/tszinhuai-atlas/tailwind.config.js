/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html','./src/**/*.{js,ts,jsx,tsx}'], theme: { extend: { colors: { imperial: '#720E18', vermilion: '#A82424', burgundy: '#390B12', gold: '#C5A15A', ivory: '#E9DCC3', ink: '#191413', jade: '#526A53' } } }, plugins: [] };
