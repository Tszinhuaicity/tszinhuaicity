import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowDown, ArrowLeft, BookOpen, Compass, MapPin, Minus, Plus, Search, Volume2, VolumeX, X } from 'lucide-react';
import { places, provinceIntro, Place } from './data';

function App() {
  const [entered, setEntered] = useState(false);
  const [selected, setSelected] = useState<Place | null>(null);
  const [query, setQuery] = useState('');
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({x:0,y:0});
  const [dragging, setDragging] = useState(false);
  const [discovered, setDiscovered] = useState<number[]>([]);
  const [journalOpen, setJournalOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const [soundReady, setSoundReady] = useState(false);
  const dragOrigin = useRef({x:0,y:0,ox:0,oy:0});
  const audioRef = useRef<{ctx:AudioContext; nodes:OscillatorNode[]; gains:GainNode[]}|null>(null);
  const filtered = useMemo(()=>places.filter(p=>p.name.toLocaleLowerCase('mn').includes(query.toLocaleLowerCase('mn'))),[query]);

  const enter = () => { setEntered(true); setTimeout(()=>document.getElementById('atlas')?.scrollIntoView({behavior:'smooth'}),120); };
  const openPlace = (p:Place) => { setSelected(p); setDiscovered(old=>old.includes(p.id)?old:[...old,p.id]); };
  const closePlace = () => setSelected(null);
  const zoomBy = (n:number) => setZoom(z=>Math.min(2.25,Math.max(.78,z+n)));
  const startSound = () => {
    try {
      if (!audioRef.current) {
        const Ctx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx:AudioContext = new Ctx();
        const notes=[146.83,196,220,293.66];
        const nodes:OscillatorNode[]=[]; const gains:GainNode[]=[];
        notes.forEach((freq,i)=>{const osc=ctx.createOscillator(); const gain=ctx.createGain(); osc.type=i%2?'triangle':'sine'; osc.frequency.value=freq; gain.gain.value=.012/(i+1); osc.connect(gain);gain.connect(ctx.destination);osc.start();nodes.push(osc);gains.push(gain);});
        audioRef.current={ctx,nodes,gains};
      }
      audioRef.current.ctx.resume(); audioRef.current.gains.forEach(g=>g.gain.setTargetAtTime(.012,audioRef.current!.ctx.currentTime,.4));
      setSoundOn(true);setSoundReady(true);
    } catch { setSoundOn(false); }
  };
  const stopSound = () => { if(audioRef.current){audioRef.current.gains.forEach(g=>g.gain.setTargetAtTime(0,audioRef.current!.ctx.currentTime,.25));} setSoundOn(false); };
  useEffect(()=>()=>{audioRef.current?.nodes.forEach(n=>n.stop());audioRef.current?.ctx.close();},[]);

  const pointerDown=(e:React.PointerEvent<SVGSVGElement>)=>{setDragging(true);dragOrigin.current={x:e.clientX,y:e.clientY,ox:offset.x,oy:offset.y};e.currentTarget.setPointerCapture(e.pointerId);};
  const pointerMove=(e:React.PointerEvent<SVGSVGElement>)=>{if(!dragging)return;setOffset({x:dragOrigin.current.ox+(e.clientX-dragOrigin.current.x)/zoom,y:dragOrigin.current.oy+(e.clientY-dragOrigin.current.y)/zoom});};
  const pointerUp=()=>setDragging(false);

  return <main>
    <div className="grain" />
    <header className="topbar"><a className="brand" href="#top" onClick={()=>{setEntered(false);setSelected(null)}}><span className="brand-seal">锦</span><span>ЦЗИНЬ’ХУАЙ <small>TIANGSHI EMPIRE · PROVINCE ATLAS</small></span></a><nav><a href="#overview">Мужийн тухай</a><a href="#atlas">Газрын зураг</a><button onClick={()=>setJournalOpen(true)}><BookOpen size={15}/> Тэмдэглэл</button></nav><button className="sound-button" onClick={()=>soundOn?stopSound():startSound()} aria-label="Дууны тохиргоо">{soundOn?<Volume2 size={17}/>:<VolumeX size={17}/>}<span>{soundOn?'Дуу асаалттай':'Дуу'}</span></button></header>

    <section id="top" className={`hero ${entered?'hero-entered':''}`}>
      <div className="hero-art" aria-hidden="true">
        <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice">
          <defs><linearGradient id="sky" x2="0" y2="1"><stop stopColor="#2a2022"/><stop offset=".55" stopColor="#9c7662"/><stop offset="1" stopColor="#e0c6a0"/></linearGradient><linearGradient id="river" x2="0" y2="1"><stop stopColor="#6d7770"/><stop offset="1" stopColor="#1c3437"/></linearGradient><linearGradient id="mount" x2="0" y2="1"><stop stopColor="#59645a"/><stop offset="1" stopColor="#252e2b"/></linearGradient></defs>
          <rect width="1600" height="900" fill="url(#sky)"/><circle cx="1160" cy="220" r="92" fill="#e8cfa2" opacity=".42"/>
          <path d="M0 490 150 310 260 405 420 215 570 430 760 170 930 425 1110 240 1280 420 1450 250 1600 430V900H0Z" fill="url(#mount)" opacity=".88"/>
          <path d="M0 565 210 430 380 540 560 390 760 560 980 390 1160 540 1370 400 1600 560V900H0Z" fill="#4d5b50" opacity=".85"/>
          <path d="M-80 610 Q250 520 450 650 T870 650 T1300 600 T1700 680 L1700 920H-80Z" fill="url(#river)"/>
          <path d="M650 600 Q790 500 930 550 Q1080 600 1160 520 Q1240 470 1320 540" fill="none" stroke="#d7c5a4" strokeWidth="5" opacity=".3"/>
          <g fill="#211719" stroke="#b58b55" strokeWidth="3"><path d="M130 570v-75l110-72 115 72v75h-20v-62H150v62Z"/><path d="M110 500 240 400 375 500l-20 12-115-80-112 80Z"/><path d="M1120 540v-115l110-76 125 76v115h-25v-98h-185v98Z"/><path d="M1090 430 1230 325 1370 430l-22 14-118-86-118 86Z"/><path d="M850 550v-78l75-53 80 53v78h-18v-63h-120v63Z"/><path d="M830 480 925 400 1020 480l-16 10-79-62-79 62Z"/></g>
          <g fill="#b82b25" stroke="#d1a75e" strokeWidth="3"><path d="M95 498 240 389 390 498 365 507 240 425 120 507Z"/><path d="M1070 432 1230 312 1390 432 1360 442 1230 352 1100 442Z"/><path d="M810 482 925 392 1040 482 1015 490 925 425 835 490Z"/></g>
          <g fill="#e5d3b3" opacity=".18"><path d="M0 480Q280 420 500 485T950 480T1600 450V570Q1300 540 1000 575T450 570T0 590Z"/><path d="M0 680Q280 620 550 675T1100 670T1600 640V740Q1200 700 900 740T300 735T0 760Z"/></g>
          {Array.from({length:18},(_,i)=><g key={i} transform={`translate(${90+i*86},${620+(i%4)*33})`} opacity=".8"><path d="M0 0q-10 -25 0 -43q10 18 0 43" stroke="#e3b86b" fill="none" strokeWidth="2"/><path d="M-8 -19h16l-2 17h-12Z" fill="#c68d42"/><path d="M-5 -15h10" stroke="#f2d6a0"/></g>)}
          <path d="M0 790Q400 735 800 790T1600 780V900H0Z" fill="#151718" opacity=".6"/>
        </svg>
      </div>
      <div className="hero-vignette" />
      <div className="hero-content"><div className="eyebrow"><span/> ТИАНШИ УЛСЫН ӨМНӨД МУЖ <span/></div><div className="seal-large">锦淮</div><h1>ЦЗИНЬ’ХУАЙ МУЖ</h1><p className="hero-sub">Манан татуулсан мөрний хөндий</p><div className="hero-rule"><i/> <span>✦</span> <i/></div><p className="hero-copy">Эртний мөрний урсгал даган нуугдсан домог, хаадын мөр, мянган жилийн дурсамж.</p><button className="enter-button" onClick={enter}>Мужийг судлах <ArrowDown size={16}/></button><div className="scroll-hint">ДООШ ГҮЙЛГЭНЭ ҮҮ · SCROLL TO EXPLORE</div></div>
      <div className="hero-stamp">天<br/>师<br/>帝国</div>
    </section>

    <section id="overview" className="overview section-wrap"><div className="section-kicker">第一卷 · THE PROVINCE</div><h2>МАНАНГИЙН ЦААНАХ <em>НУТАГ</em></h2><p className="intro-lead">Хуай мөрний урсгал, Юньшань уулсын сүүдэр хоёрын завсар орших Цзинь’Хуай — ус, газар, гар урлалын өлгий.</p><div className="overview-grid"><article className="overview-card"><span className="card-index">一 / 01</span><div className="ornament">山水</div><h3>БАЙРЛАЛ БА ГАЗАР НУТАГ</h3><p>{provinceIntro.location}</p></article><article className="overview-card"><span className="card-index">二 / 02</span><div className="ornament">稻香</div><h3>ОНЦЛОГ, ЭДИЙН ЗАСАГ</h3><p>{provinceIntro.economy}</p></article><article className="overview-card featured-card"><span className="card-index">三 / 03</span><div className="ornament">十二景</div><h3>МУЖИЙН АЛДАРТАЙ ГАЗРУУД</h3><p>Цэцэгт хүрээлэн, манант цайны талбай, хүрэл дээвэрт сүм, домогт нуур, чулуун гүүр, шөнийн асрууд — мужийн арван хоёр нууцыг газрын зургаас нээнэ үү.</p><button className="text-link" onClick={()=>document.getElementById('atlas')?.scrollIntoView({behavior:'smooth'})}>АРВАН ХОЁР ГАЗРЫГ НЭЭХ <span>↗</span></button></article></div></section>

    <section id="atlas" className="atlas-section"><div className="section-wrap"><div className="atlas-heading"><div><div className="section-kicker">第二卷 · IMPERIAL CARTOGRAPHY</div><h2>МУЖИЙН <em>ГАЗРЫН ЗУРАГ</em></h2><p>Торгон газрын зураг дээрх тэмдэглэгээг сонгож, Цзинь’Хуайн нууц газруудаар аялаарай.</p></div><div className="progress-seal"><strong>{discovered.length}<small>/12</small></strong><span>НЭЭСЭН ГАЗАР</span><div className="progress-line"><i style={{width:`${discovered.length/12*100}%`}}/></div></div></div>
      <div className="map-toolbar"><label className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Газрын нэрээр хайх..."/><kbd>⌕</kbd></label><div className="map-actions"><button onClick={()=>zoomBy(.18)} aria-label="Томруулах"><Plus size={16}/></button><button onClick={()=>zoomBy(-.18)} aria-label="Жижигрүүлэх"><Minus size={16}/></button><button onClick={()=>{setZoom(1);setOffset({x:0,y:0});setSelected(null)}}>БҮТЭН ЗУРАГ</button></div></div>
      <div className="map-frame">
        <div className="map-corner tl">✥</div><div className="map-corner tr">✥</div><div className="map-corner bl">✥</div><div className="map-corner br">✥</div>
        <svg className="map-svg" viewBox="0 0 1000 720" role="img" aria-label="Цзинь’Хуай мужийн интерактив газрын зураг" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} style={{cursor:dragging?'grabbing':'grab'}}>
          <defs><pattern id="paper" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M0 12h24M12 0v24" stroke="#8c714d" opacity=".09" strokeWidth=".5"/></pattern><linearGradient id="mapwater" x2="0" y2="1"><stop stopColor="#91a39a"/><stop offset="1" stopColor="#506c68"/></linearGradient><filter id="soft"><feGaussianBlur stdDeviation="5"/></filter></defs>
          <rect width="1000" height="720" fill="#d7c49f"/><rect width="1000" height="720" fill="url(#paper)"/>
          <g transform={`translate(${offset.x} ${offset.y}) translate(500 360) scale(${zoom}) translate(-500 -360)`}>
            <path d="M0 0H1000V720H0Z" fill="none" stroke="#9b7548" strokeWidth="2"/>
            <g fill="#a6a18a" opacity=".7"><path d="M20 110 100 35 180 90 260 18 330 90 410 25 490 110 570 35 640 100 720 25 800 95 890 30 980 110V185H20Z"/><path d="M0 210 95 160 180 220 265 150 350 215 440 155 525 220 620 155 700 215 790 150 880 215 1000 160V270H0Z"/></g>
            <g fill="none" stroke="#777d6c" strokeWidth="2" opacity=".65"><path d="M10 110q80 -80 150 -15t150 -20 150 5 150 -25 160 25 150 -30"/><path d="M25 145q80 -75 150 -15t150 -20 150 5 150 -25 160 25 150 -30"/><path d="M40 180q80 -75 150 -15t150 -20 150 5 150 -25 160 25 150 -30"/></g>
            <path d="M-20 430 C130 365 210 470 320 420 S500 350 600 425 S800 510 1020 410 L1020 520 C850 610 760 520 620 490 S430 510 300 530 S100 490 -20 550Z" fill="url(#mapwater)" opacity=".92"/>
            <path d="M-10 470 C130 405 210 510 320 460 S500 390 600 465 S800 550 1010 450" fill="none" stroke="#eee0bf" strokeWidth="3" opacity=".8"/>
            <path d="M-20 585q160 -60 300 -5t270 -5 260 30 210 -10" fill="none" stroke="#a48b65" strokeWidth="2" strokeDasharray="8 9"/>
            <g fill="none" stroke="#7e684c" strokeWidth="2" opacity=".8"><path d="M95 280q70 -80 140 0t140 0 140 0"/><path d="M650 250q80 -70 150 0t130 0"/><path d="M120 620q80 -55 150 0t150 0"/></g>
            <g fill="#8a342a" opacity=".72"><path d="M180 390v-40l38-25 38 25v40h-8v-30h-60v30Z"/><path d="M170 352 218 320 266 352l-10 5-38-25-38 25Z"/><path d="M735 315v-55l45-30 45 30v55h-10v-43h-70v43Z"/><path d="M720 265 780 225 840 265l-12 6-48-32-48 32Z"/></g>
            <g fill="#5d755e" opacity=".65"><path d="M300 330q-20 -50 0 -90 20 40 0 90m-25 -8q-20 -45 0 -75 20 35 0 75m50 0q-20 -45 0 -75 20 35 0 75"/><path d="M880 570q-20 -50 0 -90 20 40 0 90m-25 -8q-20 -45 0 -75 20 35 0 75"/></g>
            <g fontFamily="Noto Serif,serif" fill="#765f43" opacity=".72"><text x="500" y="115" textAnchor="middle" fontSize="25" letterSpacing="8">雲 山 山 脈</text><text x="500" y="610" textAnchor="middle" fontSize="19" letterSpacing="7">淮 河 · MӨРӨН</text><text x="80" y="685" fontSize="13">南境 · ӨМНӨД ХЯЗГААР</text></g>
            <g transform="translate(905 95)" stroke="#7e3328" fill="none"><path d="M0 50V0m-12 18L0 0l12 18M0 50l-8 -15h16Z" strokeWidth="2"/><text x="0" y="68" fill="#7e3328" stroke="none" textAnchor="middle" fontSize="12">N</text></g>
            {places.filter(p=>filtered.some(f=>f.id===p.id)).map(p=><g key={p.id} transform={`translate(${p.x*10} ${p.y*7.1})`} onPointerDown={e=>e.stopPropagation()} onClick={()=>openPlace(p)} className="map-marker" role="button" aria-label={p.name}>
              <circle r="19" fill="#f1e4c7" stroke="#8b3028" strokeWidth="2"/><circle r="14" fill="#81202a" stroke="#d2ae70" strokeWidth="1.5"/><text y="5" textAnchor="middle" fill="#f0dfb9" fontSize="15" fontFamily="Noto Serif,serif">{p.symbol}</text><circle r="24" fill="none" stroke="#a04c35" strokeWidth="1" opacity=".6"/>
              <text y="35" textAnchor="middle" fill="#4a2d20" stroke="#e5d4b1" strokeWidth="3" paintOrder="stroke" fontSize="13" fontFamily="Noto Serif,serif">{p.name.length>12?p.name.slice(0,11)+'…':p.name}</text>
            </g>)}
          </g>
        </svg>
        <div className="map-caption"><span>天師帝國 · 錦淮府</span><span>ХУДАЛ ЗУРАГЛАЛ · УРАН СЭТГЭМЖИЙН ГАЗАР ЗҮЙ</span><span>✦</span></div>
        <AnimatePresence>{selected&&<motion.div className="place-panel" initial={{opacity:0,x:35}} animate={{opacity:1,x:0}} exit={{opacity:0,x:35}} transition={{duration:.3}}><button className="panel-close" onClick={closePlace}><X size={17}/></button><div className="panel-art"><span>{selected.symbol}</span><div className="panel-art-lines"/></div><div className="panel-kicker">{selected.category} · 第{selected.id}景</div><h3>{selected.name}</h3><div className="chinese-name">{selected.chinese}</div>{selected.description.map((d,i)=><p key={i}>{d}</p>)}<button className="panel-back" onClick={closePlace}><ArrowLeft size={15}/> ГАЗРЫН ЗУРАГ РУУ БУЦАХ</button></motion.div>}</AnimatePresence>
        <div className="map-legend"><span><i/> Судлагдаагүй</span><span><i className="found"/> Нээсэн</span></div>
      </div>
      <div className="atlas-foot"><span>Хулганаар чирж газрын зургийг хөдөлгөнө · + / − товчоор томруулна</span><span>{filtered.length} БАЙРШИЛ ИЛЭРЛЭЭ</span></div>
      <div className="location-strip">{filtered.map(p=><button key={p.id} onClick={()=>openPlace(p)} className={discovered.includes(p.id)?'visited':''}><span>{String(p.id).padStart(2,'0')}</span>{p.name}</button>)}</div>
    </div></section>

    <section className="journal-section section-wrap"><div className="journal-ornament">卷</div><div><div className="section-kicker">第三卷 · THE CHRONICLES</div><h2>МУЖИЙН <em>ТЭМДЭГЛЭЛ</em></h2><p>Арван хоёр газрын домог, түүх, амьд ахуйг нэгэн хуйлмалд цуглуулав.</p></div><button className="journal-button" onClick={()=>setJournalOpen(true)}>ТЭМДЭГЛЭЛ НЭЭХ <BookOpen size={16}/></button></section>
    <footer><div className="footer-seal">锦淮</div><p>ЦЗИНЬ’ХУАЙ МУЖ · ТИАНШИ УЛС</p><small>Манан татуулсан мөрний хөндий · Эртний ертөнцийн уран зураглал</small><span>天 · 地 · 人</span></footer>

    <AnimatePresence>{journalOpen&&<motion.div className="journal-overlay" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><motion.aside className="journal-drawer" initial={{x:'100%'}} animate={{x:0}} exit={{x:'100%'}} transition={{type:'spring',damping:27}}><div className="drawer-head"><div><div className="section-kicker">帝國秘錄 · ARCHIVES</div><h2>МУЖИЙН ТЭМДЭГЛЭЛ</h2></div><button onClick={()=>setJournalOpen(false)}><X/></button></div><p className="drawer-intro">Цзинь’Хуайн арван хоёр газар — нээж үзэх бүрд тэмдэглэлд тань үлдэнэ.</p><div className="drawer-progress">Судалсан газар <strong>{discovered.length} / 12</strong><div><i style={{width:`${discovered.length/12*100}%`}}/></div></div><div className="journal-list">{places.map(p=><button key={p.id} onClick={()=>{setJournalOpen(false);openPlace(p);document.getElementById('atlas')?.scrollIntoView({behavior:'smooth'})}}><span className="journal-no">{String(p.id).padStart(2,'0')}</span><span><b>{p.name}</b><small>{p.category} · {p.chinese}</small></span><span className={discovered.includes(p.id)?'journal-check active':'journal-check'}>{discovered.includes(p.id)?'✓':'○'}</span></button>)}</div></motion.aside></motion.div>}</AnimatePresence>
  </main>;
}
export default App;
